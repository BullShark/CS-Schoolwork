import javax.swing.JFrame;

public class Multiply3 
{
   public static void main (String [] args)
   {
      JFrame frame = new JFrame("Simple multiply 3");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      Multiply3Panel c = new Multiply3Panel();
      frame.getContentPane().add(c);
      frame.pack();
      frame.setVisible(true);
   }
}
